package thuchanh2.quanth;

public interface Chucnang {
    boolean nhap(giangvien q);

    int checkmagiangvien(String s);

    void danhsach();

    void sapxep();

    void xoa();
}
