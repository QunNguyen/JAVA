package thuchanh2.quanth;

public interface Tingluong {
    double getTinh();
}
